from functools import cmp_to_key
from scipy.optimize import basinhopping
from multiprocessing import Pool
import time
import multiprocessing as mp
from Plotter import *
from Physics import *
from Outputter import *


def comparator(a, b):

    i = 0
    while i < len(a)-1 and a[i] == b[i]:
        i += 1
    if i == len(a):
        return 0
    if a[i] < b[i]:
        return -1
    return 1

minval = 0
xmin = np.zeros(2*N)
count =0
def print_fun(x, f, accepted):
    global minval
    global xmin
    global count
    if np.abs(f - minval) < epsilon and comparator(x, xmin) == 1:
        xmin = x
    if f <= minval - epsilon:
        xmin = x
        minval = f
        count +=1

def computing(h):
    global minval
    global xmin
    xmin  = np.zeros(2*N)
    minval = func2d(np.zeros(Dimension*N), a, b, h)[0]
    ret = basinhopping(func2d, np.zeros(Dimension * N), stepsize=1, callback=print_fun,
                       minimizer_kwargs={"method": "L-BFGS-B", "args": (a, b, h), "jac": True}, niter=N_iter)
    print('h = ' + str(h))
    print(count)
    return xmin


massh = np.arange(a_init, a_max, a_step)
mass = [[] for i in range(Dimension*N)]

start_time = time.time()

if __name__ == '__main__':
    with Pool(mp.cpu_count()) as p:
        massa = p.map(computing, massh)

    print("--- %s seconds ---" % (time.time() - start_time))
    for i, j, l in itertools.product(range(N), range(massh.size), range(Dimension)):
        mass[Dimension*i+l].append(massa[j][Dimension*i+l]+L[i][l])

    plotter2D(mass, massh)
    plotter3D(mass, massh)
    outputter(mass, massh)