from Constants import *


def outputter(mass, massh):
    file = open("output.txt", "a")
    file.write("Runs separator\n")
    file.write("%s %s\n" % (N, Dimension))
    for i in massh:
        file.write("%s " % i)
    file.write("\n")
    for j in range(Dimension * N):
        for i in mass[j]:
            file.write("%s " % i)
        file.write("\n")
    file.close()
