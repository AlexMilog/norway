import matplotlib
#matplotlib.use('agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from Physics import *


def plotter2D(mass, massh):
    colors = np.linspace(a_init, a_max, len(massh))
    for i in range(N):
        plt.scatter(mass[2 * i], mass[2 * i + 1], c=colors, cmap='plasma')
        plt.xlabel('X Coordinate')
        plt.ylabel('Y Coordinate')
        plt.title("Stiffness k = " + str(k) + "; Number of tubes N = " + str(N) + "; (v.d.W) Proximity b = " + str(b))
    cbar = plt.colorbar()
    cbar.set_label('Height')
    plt.show()


def plotter3D(mass, massh):
    ax = plt.axes(projection='3d')
    for i in range(N):
        ax.plot3D(mass[2 * i], mass[2 * i + 1], massh, 'o-')
    ax.set_xlabel('Position x')
    ax.set_ylabel('Position y')
    ax.set_zlabel('Height')
    ax.set_title("Stiffness k = " + str(k) + "; Number of tubes N = " + str(N) + "; (v.d.W) Proximity b = " + str(b))
    plt.show()