import math
import numpy as np
mult = 0.1
k = 0.001*mult
a = 1*mult
N = 9
b = 0.005
Precision = 0.00001

N_iter = 80
N_rand_start = 10
#L = []
epsilon = 0.1*mult
Dimension = 2

#for i in range(N):
#    L.append((i, 0))
#    L.append((i, 1))

#for i in range(N):
#    for j in range(N):
#        L.append((i, j))
L = [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]
#L = [(0, 0)]
#for i in range(6):
#    L.append([np.cos(2*math.pi*i/6), np.sin(2*math.pi*i/6)])
#N = len(L)


a_init, a_max, steps = 0.1, 0.25, 6
a_step = (a_max-a_init) / float(steps)
